import React from 'react';
import PropTypes from 'prop-types'; 
import './Odliczanie.css';
import {godzinaMinutadoSekund, sekundyDoGodzinMinutSekund} from './utilsy'

const Odliczanie = props =>{
    const sekundyLekcje = godzinaMinutadoSekund(props.czasG, props.czasM);
    const sekundyTeraz= godzinaMinutadoSekund(props.obecnyCzas.godzina, props.obecnyCzas.minuta)+ props.obecnyCzas.sekunda;
    const pozostaloSekund = sekundyLekcje - sekundyTeraz;
    const pozostaloSekundTekst = pozostaloSekund >0 ? sekundyDoGodzinMinutSekund(pozostaloSekund): "Ta lekcja odbędzie się dopiero jutro";

    return(
    <div className="Odliczanie">
        <div className="Odliczanie_kasowanie">
            <i className="edycja" onClick={()=>props.edytujLekcje(props.ile)}>[E]</i>
            <b className="iks" onClick={()=>props.Usun(props.ile)}>x</b>
        </div>
        {props.ile}. <strong>{props.name}</strong> {props.czasG} : {props.czasM}
        <br />
        <i>do tej lekcji pozostało jeszcze: </i>{pozostaloSekundTekst}
    </div>
    );
};

Odliczanie.propTypes={
    obecnyCzas: PropTypes.shape({
        godzina: PropTypes.number,
        minuta: PropTypes.number,
        sekunda: PropTypes.number
    }),
    name: PropTypes.string,
    czasG: PropTypes.number,
    czasM: PropTypes.number,
    edytujLekcje: PropTypes.func,
    Usun: PropTypes.func
};

export default Odliczanie;